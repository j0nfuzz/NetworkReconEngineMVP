$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$env:PYTHONUNBUFFERED = '1'
$pyExe = Join-Path $scriptDir 'python\python.exe'
$runPortable = Join-Path $scriptDir 'run_portable.py'
& $pyExe -u $runPortable @args
