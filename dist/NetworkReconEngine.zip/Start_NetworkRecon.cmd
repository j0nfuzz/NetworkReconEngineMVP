@echo off
cd /d "%~dp0"
set PYTHONUNBUFFERED=1
python\python.exe -u run_portable.py %*
